# Мир Золота — landing page

Статический адаптивный лендинг на HTML/CSS/JS. Не требует сборки.

## Деплой на Vercel
1. Распакуйте архив.
2. Загрузите папку в новый GitHub-репозиторий.
3. В Vercel выберите **Add New → Project** и импортируйте репозиторий.
4. Framework Preset: **Other**; Build Command и Output Directory оставьте пустыми/по умолчанию.
5. Нажмите Deploy.

Можно также развернуть через Vercel CLI из этой папки: `vercel --prod`.

Контент и адреса взяты из предоставленного Taplink. Фотографии загружаются с Unsplash; шрифты — Google Fonts.
